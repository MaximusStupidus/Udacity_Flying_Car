# Control Architecture

Some starting points:

- [Control Architecture](Control%20Architecture/Lesson%203%20-%20Control%20Architecture.ipynb) (notebook)
- [Coupling](4.%20Coupling.md) (writeup)